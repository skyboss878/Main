// backend/start_workers.js
require('dotenv').config(); // Load environment variables first
require('./queue/worker'); // This will initialize and start the BullMQ workers

console.log('🚀 BullMQ Workers started. Listening for jobs...');
// You might also connect to DB here if workers need direct DB access for their tasks.
